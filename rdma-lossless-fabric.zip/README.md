# RDMA Lossless Fabric with RoCEv2

This repository documents the configuration and tuning of a lossless RDMA fabric using RoCEv2 for distributed AI/ML workloads. It includes configuration files, scripts, and telemetry tools for RDMA network validation and tuning.

## Structure

- `docs/`: High-level configuration and architecture overview
- `configs/switch/`: Example switch configs (PFC, ECN)
- `configs/node/`: NIC and OS-level tuning configs
- `scripts/`: Benchmarking and telemetry scripts

## Quick Start

```bash
cd scripts
bash run_rdma_benchmark.sh
```

Refer to `docs/lossless_rdma_rocev2.md` for full details.
