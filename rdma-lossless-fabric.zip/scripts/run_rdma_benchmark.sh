#!/bin/bash
echo "Running RDMA benchmark using ib_read_bw..."
ib_read_bw -d mlx5_0 -F -x 3 -n 1000000
