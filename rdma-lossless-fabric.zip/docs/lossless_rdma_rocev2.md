# Lossless RDMA Fabric Configuration – RoCEv2

## Overview
This document outlines the configuration steps and tuning parameters used to achieve a lossless RDMA fabric for AI/ML training workloads using RoCEv2 over Ethernet. The environment includes VXLAN VRFs, ECN, PFC, and benchmarking via `perftest`.

## Architecture Summary
- Fabric Type: Layer 2/3 Ethernet with VXLAN
- Transport: RDMA over Converged Ethernet (RoCEv2)
- Topology: Spine-Leaf with 100G/200G interconnects
- Workload: Distributed GPU training (PyTorch/Horovod)
- NICs: Mellanox ConnectX-6/7
- Switch OS: SONiC / Cumulus Linux
- Kubernetes: GPU nodes orchestrated by Cluster API and Talos Linux
- Telemetry: Prometheus + custom `rocm-smi` exporter + `ethtool` counters

## Key Tuning Parameters
... (truncated for brevity)
